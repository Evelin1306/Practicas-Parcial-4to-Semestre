﻿namespace Practica_2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panelregistro = new System.Windows.Forms.Panel();
            this.txtedad = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.txtcorreo = new System.Windows.Forms.TextBox();
            this.panelmostrar = new System.Windows.Forms.Panel();
            this.dataCorreos = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Correos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Edad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Editar = new System.Windows.Forms.DataGridViewImageColumn();
            this.Eliminar = new System.Windows.Forms.DataGridViewImageColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAagregar = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAmostar = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAsalir = new System.Windows.Forms.ToolStripMenuItem();
            this.panelregistro.SuspendLayout();
            this.panelmostrar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataCorreos)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelregistro
            // 
            this.panelregistro.Controls.Add(this.txtedad);
            this.panelregistro.Controls.Add(this.txtnombre);
            this.panelregistro.Controls.Add(this.txtcorreo);
            this.panelregistro.Location = new System.Drawing.Point(12, 29);
            this.panelregistro.Name = "panelregistro";
            this.panelregistro.Size = new System.Drawing.Size(776, 91);
            this.panelregistro.TabIndex = 0;
            this.panelregistro.Visible = false;
            // 
            // txtedad
            // 
            this.txtedad.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtedad.Location = new System.Drawing.Point(575, 25);
            this.txtedad.Name = "txtedad";
            this.txtedad.Size = new System.Drawing.Size(172, 33);
            this.txtedad.TabIndex = 2;
            this.txtedad.Text = "Escribe la edad";
            this.txtedad.TextChanged += new System.EventHandler(this.txtedad_TextChanged);
            this.txtedad.Enter += new System.EventHandler(this.txtedad_Enter);
            this.txtedad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtedad_KeyPress);
            this.txtedad.Leave += new System.EventHandler(this.txtedad_Leave);
            // 
            // txtnombre
            // 
            this.txtnombre.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnombre.Location = new System.Drawing.Point(305, 25);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(180, 33);
            this.txtnombre.TabIndex = 1;
            this.txtnombre.Text = "Escribe un nombre";
            this.txtnombre.Enter += new System.EventHandler(this.textBox2_Enter);
            this.txtnombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnombre_KeyPress);
            this.txtnombre.Leave += new System.EventHandler(this.txtnombre_Leave);
            // 
            // txtcorreo
            // 
            this.txtcorreo.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcorreo.Location = new System.Drawing.Point(54, 25);
            this.txtcorreo.Name = "txtcorreo";
            this.txtcorreo.Size = new System.Drawing.Size(164, 33);
            this.txtcorreo.TabIndex = 0;
            this.txtcorreo.Text = "Escribe un correo";
            this.txtcorreo.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtcorreo.Enter += new System.EventHandler(this.txtcorreo_Enter);
            this.txtcorreo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcorreo_KeyPress);
            this.txtcorreo.Leave += new System.EventHandler(this.txtcorreo_Leave);
            // 
            // panelmostrar
            // 
            this.panelmostrar.Controls.Add(this.dataCorreos);
            this.panelmostrar.Location = new System.Drawing.Point(12, 139);
            this.panelmostrar.Name = "panelmostrar";
            this.panelmostrar.Size = new System.Drawing.Size(776, 299);
            this.panelmostrar.TabIndex = 1;
            this.panelmostrar.Visible = false;
            // 
            // dataCorreos
            // 
            this.dataCorreos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataCorreos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Correos,
            this.Nombre,
            this.Edad,
            this.Editar,
            this.Eliminar});
            this.dataCorreos.Location = new System.Drawing.Point(3, 3);
            this.dataCorreos.Name = "dataCorreos";
            this.dataCorreos.RowHeadersWidth = 51;
            this.dataCorreos.RowTemplate.Height = 24;
            this.dataCorreos.Size = new System.Drawing.Size(773, 298);
            this.dataCorreos.TabIndex = 0;
            this.dataCorreos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataCorreos_CellClick);
            // 
            // Id
            // 
            this.Id.HeaderText = "Id";
            this.Id.MinimumWidth = 6;
            this.Id.Name = "Id";
            this.Id.Width = 40;
            // 
            // Correos
            // 
            this.Correos.HeaderText = "Correos";
            this.Correos.MinimumWidth = 6;
            this.Correos.Name = "Correos";
            this.Correos.Width = 125;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.MinimumWidth = 6;
            this.Nombre.Name = "Nombre";
            this.Nombre.Width = 125;
            // 
            // Edad
            // 
            this.Edad.HeaderText = "Edad";
            this.Edad.MinimumWidth = 6;
            this.Edad.Name = "Edad";
            this.Edad.Width = 50;
            // 
            // Editar
            // 
            this.Editar.HeaderText = "Editar";
            this.Editar.Image = ((System.Drawing.Image)(resources.GetObject("Editar.Image")));
            this.Editar.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Editar.MinimumWidth = 6;
            this.Editar.Name = "Editar";
            this.Editar.Width = 75;
            // 
            // Eliminar
            // 
            this.Eliminar.HeaderText = "Eliminar";
            this.Eliminar.Image = ((System.Drawing.Image)(resources.GetObject("Eliminar.Image")));
            this.Eliminar.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Eliminar.MinimumWidth = 6;
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.Width = 75;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAagregar,
            this.mnuAmostar,
            this.mnuAsalir});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.archivoToolStripMenuItem.Text = "Archivo";
            // 
            // mnuAagregar
            // 
            this.mnuAagregar.Name = "mnuAagregar";
            this.mnuAagregar.Size = new System.Drawing.Size(146, 26);
            this.mnuAagregar.Text = "Agregar";
            this.mnuAagregar.Click += new System.EventHandler(this.mnuAagregar_Click);
            // 
            // mnuAmostar
            // 
            this.mnuAmostar.Name = "mnuAmostar";
            this.mnuAmostar.Size = new System.Drawing.Size(146, 26);
            this.mnuAmostar.Text = "Mostar";
            this.mnuAmostar.Click += new System.EventHandler(this.mnuAmostar_Click);
            // 
            // mnuAsalir
            // 
            this.mnuAsalir.Name = "mnuAsalir";
            this.mnuAsalir.Size = new System.Drawing.Size(146, 26);
            this.mnuAsalir.Text = "Salir";
            this.mnuAsalir.Click += new System.EventHandler(this.mnuAsalir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelmostrar);
            this.Controls.Add(this.panelregistro);
            this.Controls.Add(this.menuStrip1);
            this.MaximumSize = new System.Drawing.Size(818, 497);
            this.MinimumSize = new System.Drawing.Size(818, 497);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registro de correos";
            this.panelregistro.ResumeLayout(false);
            this.panelregistro.PerformLayout();
            this.panelmostrar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataCorreos)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelregistro;
        private System.Windows.Forms.Panel panelmostrar;
        private System.Windows.Forms.TextBox txtedad;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.TextBox txtcorreo;
        private System.Windows.Forms.DataGridView dataCorreos;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuAagregar;
        private System.Windows.Forms.ToolStripMenuItem mnuAmostar;
        private System.Windows.Forms.ToolStripMenuItem mnuAsalir;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Correos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Edad;
        private System.Windows.Forms.DataGridViewImageColumn Editar;
        private System.Windows.Forms.DataGridViewImageColumn Eliminar;
    }
}

