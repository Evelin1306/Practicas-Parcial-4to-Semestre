﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_2
{
    public partial class Form1 : Form
    {
        private bool estado1 = false;
        private bool estado2 = false;
        private int _id = -1;
        private int columna = -1;
        private string nombre, edad, cor;
        public Form1()
        {
            InitializeComponent();
            txtnombre.ForeColor = Color.Gray;
            txtcorreo.ForeColor = Color.Gray;
            txtedad.ForeColor = Color.Gray;

        }
        private void Guardar()
        {       string n = txtnombre.Text;
                string c = txtcorreo.Text;
                string d = txtedad.Text;
            if (n.Length == 0 && c.Length == 0 && d.Length == 0)
            {
                MessageBox.Show("Datos vacios, porfavor llenalos");
            }
            else
            {
                if (c.Equals("Escribe un correo")
                    || n.Equals("Escribe un nombre")
                    || d.Equals("Escribe una edad"))
                {
                    MessageBox.Show("Datos vacios, llenalos porfavor");
                }
                else {       
                    string nombreArchivo = "datos.csv";
                    StreamWriter archivo = File.AppendText(nombreArchivo);
                    archivo.WriteLine($"{c},{n},{d}");
                    archivo.Close();
                    MessageBox.Show("Datos guardados correctamente");
                    dataCorreos.Rows.Clear();
                    Mostrardatos();
                } 
            }
        }
        private void Mostrardatos()
        {
            //MessageBox.Show("Cargar Datos", "Ventana");
            if (File.Exists("datos.csv"))
            {
                StreamReader streamReader = File.OpenText("datos.csv");
                string renglon = " ";
                int c = 0;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            c++;
                            dataCorreos.Rows.Add(c.ToString(), partes[0], partes[1], partes[2]);

                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error");
                    }

                } while (renglon != null);
                streamReader.Close();
            }
            else
            {
                MessageBox.Show("Error, no hay datos guardados");
            }
        }
        private void Eliminardatos(string cor)
        {
            if (_id != -1)
            { 
                StreamReader streamReader = File.OpenText("datos.csv");
                string renglon = " ";
                int c = 0;
                StreamWriter aux = null;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            if (partes[0].Equals(c))
                            {

                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = partes[0] + "," + partes[1];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error");
                    }

                } while (renglon != null);
                streamReader.Close();
                File.Delete("datos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "datos.csv");
                    File.Delete("prueba.csv");
                }

                dataCorreos.Rows.RemoveAt(_id);
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void mnuAagregar_Click(object sender, EventArgs e)
        {
            estado1 = !estado1;
            panelregistro.Visible = estado1;

        }

        private void mnuAmostar_Click(object sender, EventArgs e)
        {
            estado2 = !estado2;
            panelmostrar.Visible = estado2;
            Mostrardatos();
        }

        private void mnuAsalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtcorreo_Enter(object sender, EventArgs e)
        {
            if (txtcorreo.Text == "Escribe un correo")
            {
                txtcorreo.Text = "";
                txtcorreo.ForeColor = Color.Black;
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (txtnombre.Text == "Escribe un nombre") {
                txtnombre.Text = "";
                txtnombre.ForeColor = Color.Black;
            }
           
        }

        private void txtnombre_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtnombre.Text))
            {
                txtnombre.Text = "Escribe un nombre";
                txtnombre.ForeColor = Color.Black;
            }
        }

        private void txtcorreo_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtcorreo.Text))
            {
                txtcorreo.Text = "Escribe un correo";
                txtcorreo.ForeColor = Color.Black;
            }
        }

        private void txtedad_Enter(object sender, EventArgs e)
        {
            if (txtedad.Text == "Escribe la edad")
            {
                txtedad.Text = "";
                txtedad.ForeColor = Color.Black;
            }
        }

        private void txtedad_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtedad.Text))
            {
                txtedad.Text = "Escribe la edad";
                txtedad.ForeColor = Color.Black;
            }
        }

        private void txtcorreo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 97 && e.KeyChar <= 122)
                || (e.KeyChar == 08)
                || (e.KeyChar == 46)
                || (e.KeyChar == 64)
                || (e.KeyChar == 95)
                || (e.KeyChar >= 48 && e.KeyChar <= 57) || (e.KeyChar == 13))
            {
                if (e.KeyChar == 13)
                {
                    Guardar();
                }
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error de datos", "Error");
            }
        }

        private void txtnombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 97 && e.KeyChar <= 122)
                || (e.KeyChar == 08)
                || (e.KeyChar == 32)
                || (e.KeyChar >= 65 && e.KeyChar <= 90)|| (e.KeyChar == 13))
            {
                if (e.KeyChar == 13)
                {
                    Guardar();
                }
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error de datos", "Error");
            }
        }

        private void txtedad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == 08)
                || (e.KeyChar >= 48 && e.KeyChar <= 57 )||(e.KeyChar == 13))
            {
                if (e.KeyChar == 13) {
                Guardar();   
            }

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error de datos", "Error");
            }
            
        }

        private void txtedad_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataCorreos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;
            columna = e.ColumnIndex;
            if (_id != -1)
            {
                cor = dataCorreos.Rows[_id].Cells[1].Value.ToString();
                nombre = dataCorreos.Rows[_id].Cells[2].Value.ToString();
                edad = dataCorreos.Rows[_id].Cells[3].Value.ToString();
            }
            else
            {
                MessageBox.Show("Elige un elemento de la lista");
            }
            if (columna == 4) {
                txtcorreo.Text = cor;
                txtnombre.Text = nombre;
                txtedad.Text = edad;
                panelregistro.Visible = true;
                txtnombre.ForeColor = Color.Black;
                txtcorreo.ForeColor = Color.Black;
                txtedad.ForeColor = Color.Black;

            }
            if (columna == 5) {
                Eliminardatos(cor);     
                       
            }
        }
    }
}
