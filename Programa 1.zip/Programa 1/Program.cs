﻿/* Utilizando dos archivos van a llenar un archivo con 10 datos, que involucre nombre, 
 * edad y sexo de 10 personas
 * */
class Program {
    private static Leer le = new Leer(); 
    static void Main(string[] args) {
        string nombre, sexo, edad;
        int c = 0;
        while (true)
        {
            Console.WriteLine("Escribe el nombre de una persona");
            nombre = Console.ReadLine();
            if (le.ValidarNombre(nombre))
            {
                Console.WriteLine("Escribe la edad");
                edad = Console.ReadLine();
                if (le.ValidarNumeros(edad))
                {
                    Console.WriteLine("Escribe el sexo");
                    sexo = Console.ReadLine();
                    if (le.Validarsexo(sexo))
                    {
                        le.ingresardatos(nombre, edad, sexo, c);
                        c++;
                        if (c == 10)
                        {
                            break;
                        }
                    }
                    else {
                        Console.WriteLine("Solo ingresa letras");
                    }
                }
                else {
                    Console.WriteLine("Edad Incorrecta");
                }
            }
            else {
                Console.WriteLine("Nombre incorrecto");
            }    
        }
    }
}