﻿using System.Text.RegularExpressions;
class Leer
{
    public void ingresardatos(string nombre, string edad, string sexo, int c) {
        string archivo = "datos.txt";
        StreamWriter archi = null;
        archi = File.AppendText(archivo);
        archi.WriteLine(nombre, edad, sexo);
        archi.Close();
        Console.WriteLine("Datos guardados correctamente.");
        c++;
    }
    public bool ValidarNumeros(string edad)
    {
        if (edad == null)
        {
            return false;
        }
        bool r = false;
        r = (Regex.IsMatch(edad, @"^[0-9]+$"));
        return r;
    }
    public bool Validarsexo(string sexo)
    {
        bool r = false;
        if (Regex.IsMatch(sexo, @"^[a-zA-Z _]+$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
    public bool ValidarNombre(String nombre)
    {
        bool r = false;
        if (Regex.IsMatch(nombre, @"^[a-zA-Z _]+$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
    public void Promediar(string edad) { 
    }
}

