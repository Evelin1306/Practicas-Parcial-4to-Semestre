﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Programa_2
{
    public partial class Mostrar : Form
    {
        private int _id = -1;
        private string u = "";
        private string p = "";
        private int columna = 0;

        public Mostrar()
        {
            InitializeComponent();
            Mostrardatos();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;
            columna = e.ColumnIndex;
            if (_id != -1)
            {
                u = dataDatos.Rows[_id].Cells[1].Value.ToString();
                p = dataDatos.Rows[_id].Cells[2].Value.ToString();
                //MessageBox.Show(u + " : " + p);
                //MessageBox.Show(_id.ToString());
            }
            else
            {
                MessageBox.Show("Elige un elemento de la lista");
            }
            if (columna == 3)
            {
                Modificar(u,p);
                Mostrardatos();
            }
            else if (columna == 4) {
                MessageBoxButtons botones = MessageBoxButtons.YesNo;
                MessageBoxIcon icon = MessageBoxIcon.Question;
                DialogResult respuesta = MessageBox.Show("Esta seguro?","Alerta",botones, icon);
                if (respuesta == DialogResult.Yes)
                {
                    Eliminardatos();
                    dataDatos.Rows.Clear();
                    Mostrardatos();
                }
               
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

        }

        private void txtEdad_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEdad_Click(object sender, EventArgs e)
        {

        }

        private void lblNombre_Click(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

        }

        private void archivoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    
        private void Mostrardatos()
        {
            //MessageBox.Show("Cargar Datos", "Ventana");
            if (File.Exists("datos.csv"))
            {
                StreamReader streamReader = File.OpenText("Datos.csv");
                string renglon = " ";
                int c = 0;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            c++;
                            dataDatos.Rows.Add(c.ToString(), partes[0], partes[1]);

                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error");
                    }

                } while (renglon != null);
                streamReader.Close();
            }
            else
            {
                MessageBox.Show("Error, no hay datos guardados");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            dataDatos.Rows.Clear();
            Mostrardatos();

        }
        private void Eliminardatos() { 
           if (_id != -1) { 
                
                //MessageBox.Show("Cargar Datos", "Ventana");
                StreamReader streamReader = File.OpenText("Datos.csv");
                string renglon = " ";
                int c = 0;
                StreamWriter aux = null;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            if (partes[1].Equals(u))
                            {
                                
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = partes[0] + "," + partes[1];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error");
                    }

                } while (renglon != null);
                streamReader.Close();
                File.Delete("Datos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv","Datos.csv");
                    File.Delete("prueba.csv");
                }
                
                dataDatos.Rows.RemoveAt(_id);
            } 
        }
        private void button3_Click(object sender, EventArgs e)
        {
            
        }
        private void Modificar(string u, string p) { 
            if (_id != -1)
                {
                dataDatos.Rows.RemoveAt(_id);
                StreamReader archivo = File.OpenText("datos.csv");
                string renglon = " ";
                StreamWriter aux = null;
                int c = 0;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');

                            if (partes[0].Equals(u))
                            {
                                string us = Interaction.InputBox("Ingresa un nombre",
                                    "Agregar Nombre");
                                string ed = Interaction.InputBox("Ingresa una Edad",
                                    "Agregar Edad");
                                if (us.Length == 0) {
                                    us = u;
                                }
                                if (ed.Length == 0) { 
                                    ed = p;
                                }
                                aux = File.AppendText("prueba.csv");
                                string cadena = us + " " + ed;
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = partes[0] + "," + partes[1];
                                aux.WriteLine(cadena);
                                aux.Close();

                            }
                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error");
                    }

                } while (renglon != null);

                archivo.Close();
                File.Delete("datos.csv");
                File.Move("prueba.csv", "datos.csv");
                File.Delete("prueba.csv");
                dataDatos.Rows.RemoveAt(_id);
                }
            }
        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
    }

