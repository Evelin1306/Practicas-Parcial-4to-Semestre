﻿using System;
using System.Text.RegularExpressions;
class Validaciones
{
    public bool ValidarNumeros(string e)
    {
        bool r = false;
        if (Regex.IsMatch(e, @"^[0-9]+$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
    public bool ValidarLetras(string n)
    {
        bool r = false;
        //@"^[a-zA-Z _]$";
        if (Regex.IsMatch(n, @"^[a-zA-Z _]+$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
    public bool ValidarTelefono(string tel)
    {
        bool r = false;
        //@"^[a-zA-Z _]$";
        if (Regex.IsMatch(tel, " **\\d(9,10)$"))
        {
            r = true;
        }
        else
        {
            r = false;
        }
        return r;
    }
}
