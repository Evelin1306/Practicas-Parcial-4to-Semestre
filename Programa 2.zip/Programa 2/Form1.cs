﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa_2
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            StreamWriter archivo = null;
            Validaciones val = new Validaciones();
            //MessageBox.Show("Hola Mundo");
            string nombre = txtNombre.Text;
            string edad = txtEdad.Text;
            if (val.ValidarLetras(nombre) && val.ValidarNumeros(edad))
            {
                archivo = File.AppendText("Datos.csv");
                string cadena = nombre + "," + edad;
                archivo.WriteLine(cadena);
                archivo.Close();
                txtNombre.Text = "";
                txtEdad.Text = "";
                MessageBox.Show("Datos Guardados");
            }
            else {
                MessageBox.Show("Datos Incorrectos");
                txtNombre.Text = "";
                txtEdad.Text = "";
            }

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuAMostrar_Click(object sender, EventArgs e)
        {
            Mostrar mostrar = new Mostrar();
            mostrar.ShowDialog(this);
            
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 65 && e.KeyChar <= 90)
                ||(e.KeyChar >= 97 && e.KeyChar <= 122)
                || (e.KeyChar == 32) || (e.KeyChar == 08)) {

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error, dato no valido");
            }
        }

        private void txtEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || (e.KeyChar == 08))
            {

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error, dato no valido");
            }

        }
    }
}
