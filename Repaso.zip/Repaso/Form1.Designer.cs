﻿namespace Repaso
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            datanombres = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            edad = new DataGridViewTextBoxColumn();
            nombre = new DataGridViewTextBoxColumn();
            panel2 = new Panel();
            btnsalir = new Button();
            btnagregar = new Button();
            txtedad = new TextBox();
            txtnombre = new TextBox();
            lbledad = new Label();
            lnlnombre = new Label();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            menuStrip1 = new MenuStrip();
            archivoToolStripMenuItem = new ToolStripMenuItem();
            modificarToolStripMenuItem = new ToolStripMenuItem();
            buscarToolStripMenuItem = new ToolStripMenuItem();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)datanombres).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(datanombres);
            panel1.Location = new Point(12, 31);
            panel1.Name = "panel1";
            panel1.Size = new Size(884, 226);
            panel1.TabIndex = 0;
            // 
            // datanombres
            // 
            datanombres.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            datanombres.Columns.AddRange(new DataGridViewColumn[] { ID, edad, nombre });
            datanombres.Location = new Point(0, 3);
            datanombres.Name = "datanombres";
            datanombres.RowHeadersWidth = 51;
            datanombres.Size = new Size(881, 230);
            datanombres.TabIndex = 0;
            datanombres.CellContentClick += datanombres_CellContentClick;
            // 
            // ID
            // 
            ID.HeaderText = "Id";
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.Width = 90;
            // 
            // edad
            // 
            edad.HeaderText = "Edad";
            edad.MinimumWidth = 6;
            edad.Name = "edad";
            edad.Width = 125;
            // 
            // nombre
            // 
            nombre.HeaderText = "Nombre";
            nombre.MinimumWidth = 6;
            nombre.Name = "nombre";
            nombre.Width = 150;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnsalir);
            panel2.Controls.Add(btnagregar);
            panel2.Controls.Add(txtedad);
            panel2.Controls.Add(txtnombre);
            panel2.Controls.Add(lbledad);
            panel2.Controls.Add(lnlnombre);
            panel2.Location = new Point(12, 280);
            panel2.Name = "panel2";
            panel2.Size = new Size(429, 232);
            panel2.TabIndex = 1;
            // 
            // btnsalir
            // 
            btnsalir.Font = new Font("Segoe UI Symbol", 13.8F, FontStyle.Bold);
            btnsalir.Location = new Point(263, 143);
            btnsalir.Name = "btnsalir";
            btnsalir.Size = new Size(119, 44);
            btnsalir.TabIndex = 5;
            btnsalir.Text = "Salir";
            btnsalir.UseVisualStyleBackColor = true;
            btnsalir.Click += btnsalir_Click;
            // 
            // btnagregar
            // 
            btnagregar.Font = new Font("Segoe UI Symbol", 13.8F, FontStyle.Bold);
            btnagregar.Location = new Point(56, 143);
            btnagregar.Name = "btnagregar";
            btnagregar.Size = new Size(127, 44);
            btnagregar.TabIndex = 4;
            btnagregar.Text = "Agregar";
            btnagregar.UseVisualStyleBackColor = true;
            btnagregar.Click += btnagregar_Click;
            // 
            // txtedad
            // 
            txtedad.Font = new Font("Segoe UI Symbol", 13.8F, FontStyle.Bold);
            txtedad.Location = new Point(152, 66);
            txtedad.Name = "txtedad";
            txtedad.Size = new Size(263, 38);
            txtedad.TabIndex = 3;
            // 
            // txtnombre
            // 
            txtnombre.Font = new Font("Segoe UI Symbol", 13.8F, FontStyle.Bold);
            txtnombre.Location = new Point(152, 21);
            txtnombre.Name = "txtnombre";
            txtnombre.Size = new Size(264, 38);
            txtnombre.TabIndex = 2;
            // 
            // lbledad
            // 
            lbledad.AutoSize = true;
            lbledad.Font = new Font("Segoe UI Symbol", 13.8F, FontStyle.Bold);
            lbledad.Location = new Point(42, 73);
            lbledad.Name = "lbledad";
            lbledad.Size = new Size(70, 31);
            lbledad.TabIndex = 1;
            lbledad.Text = "Edad";
            // 
            // lnlnombre
            // 
            lnlnombre.AutoSize = true;
            lnlnombre.Font = new Font("Segoe UI Symbol", 13.8F, FontStyle.Bold);
            lnlnombre.Location = new Point(42, 24);
            lnlnombre.Name = "lnlnombre";
            lnlnombre.Size = new Size(104, 31);
            lnlnombre.TabIndex = 0;
            lnlnombre.Text = "Nombre";
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox1);
            panel3.Location = new Point(462, 280);
            panel3.Name = "panel3";
            panel3.Size = new Size(434, 232);
            panel3.TabIndex = 2;
            panel3.Paint += panel3_Paint;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(428, 226);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { archivoToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(908, 28);
            menuStrip1.TabIndex = 3;
            menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            archivoToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { buscarToolStripMenuItem, modificarToolStripMenuItem });
            archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            archivoToolStripMenuItem.Size = new Size(73, 24);
            archivoToolStripMenuItem.Text = "Archivo";
            // 
            // modificarToolStripMenuItem
            // 
            modificarToolStripMenuItem.Name = "modificarToolStripMenuItem";
            modificarToolStripMenuItem.Size = new Size(156, 26);
            modificarToolStripMenuItem.Text = "Modificar";
            // 
            // buscarToolStripMenuItem
            // 
            buscarToolStripMenuItem.Name = "buscarToolStripMenuItem";
            buscarToolStripMenuItem.Size = new Size(156, 26);
            buscarToolStripMenuItem.Text = "Buscar";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(908, 563);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            MaximumSize = new Size(926, 610);
            MinimumSize = new Size(926, 610);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)datanombres).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private PictureBox pictureBox1;
        private DataGridView datanombres;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn edad;
        private DataGridViewTextBoxColumn nombre;
        private Button btnsalir;
        private Button btnagregar;
        private TextBox txtedad;
        private TextBox txtnombre;
        private Label lbledad;
        private Label lnlnombre;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem archivoToolStripMenuItem;
        private ToolStripMenuItem modificarToolStripMenuItem;
        private ToolStripMenuItem buscarToolStripMenuItem;
    }
}
