namespace Repaso
{
    public partial class Form1 : Form
    {
        private int fila, columna;
        private string nombreB;

        public Form1()
        {
            InitializeComponent();
            cargardatos();
            datanombres.AllowUserToAddRows = false;// Elimina la fila en blanco al final
            datanombres.ReadOnly = true; //Desactiva la edici�n directa del dataGrid
        }
        private void cargardatos()
        {
            if (File.Exists("nombres.csv"))
            {
                StreamReader streamReader = File.OpenText("nombres.csv");
                string renglon = " ";
                int c = 0;
                datanombres.Rows.Clear();
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            c++;
                            datanombres.Rows.Add(c, partes[0], partes[1]);

                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error");
                    }

                } while (renglon != null);
                streamReader.Close();
            }
            else
            {
                MessageBox.Show("Error, no hay datos guardados");
            }

        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        private void btnagregar_Click(object sender, EventArgs e)
        {
            StreamWriter streamWriter;
            string nombre = txtnombre.Text;
            string edad = txtedad.Text;
            streamWriter = File.AppendText("nombres.csv");
            streamWriter.WriteLine(nombre, edad);
            streamWriter.Close();
            MessageBox.Show("Datos Guardados", "Mensaje");
            txtnombre.Text = "";
            txtedad.Text = "";
            cargardatos();
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void datanombres_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            fila = e.RowIndex;
            columna = e.ColumnIndex;
            if (columna == 3)
            {
                nombreB = datanombres.Rows[fila].Cells[1].Value.ToString();
                Eliminarnombre(nombreB);
                MessageBox.Show("Nombre eliminado","Mensaje");
                cargardatos();


            }
        }
        private void Eliminarnombre(string n) { 

        }
    }
}
