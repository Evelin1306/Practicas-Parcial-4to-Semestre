﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa_4
{
    public partial class Productos : Form
    {
        private string rutaimagenlocal = "", imagenlocal = "";
        private int _id = -1;
        private string codigoArchivo;
        private string nombrep, preciop, imagenp;
        List<string> img = new List<string>();
        public Productos()
        {
            InitializeComponent();
            Mostrardatos();
            dataProductos.AllowUserToAddRows = false;// Elimina la fila en blanco al final
            dataProductos.ReadOnly = true; //Desactiva la edición directa del dataGrid
        }
        private void Mostrardatos()
        {
            dataProductos.Rows.Clear();
            if (File.Exists("productos.csv"))
            {
                StreamReader streamReader = File.OpenText("productos.csv");
                string renglon = " ";
                int c = 0;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            c++;
                            dataProductos.Rows.Add(partes[0], partes[1], partes[2], Image.FromFile(partes[3]));

                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error");
                    }

                } while (renglon != null);
                streamReader.Close();
            }
            else
            {
                MessageBox.Show("Error, no hay datos guardados");
            }
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void btnaceptar_Click(object sender, EventArgs e)
        {   StreamWriter streamWriter;
            string productos = "productos.csv";
            string nombre = txtproducto.Text;
            string precio = txtprecio.Text;
            if (nombre.Length == 0 || precio.Length == 0)
            {
                MessageBox.Show("Faltan datos", "Alerta");
            }
            else
            {
                string codigo = nombre.Substring(0, 2);
                int hsistema = DateTime.Now.Hour;
                codigo += hsistema.ToString();
                lblcodigo2.Text = codigo;
                streamWriter = File.AppendText(productos);
                streamWriter.Write(codigo + "," + nombre + "," + precio + "," + rutaimagenlocal);
                streamWriter.Close();
                MessageBox.Show("Producto guardado", "Mensaje");
                Mostrardatos();
                imgproducto.Image.Dispose();
                imgproducto = null;
                txtproducto.Text = "";
                txtprecio.Text = "";
                lblcodigo2.Text = "";
            }    
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuaagregar_Click(object sender, EventArgs e)
        {

        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {

            
        }

        private void btnbuscarp_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            string rutaimagen = "";
            string rutacarpeta = @"\imagenes";
            string rutaraiz = @"imagenes";
            string ruta = "";
            if (txtproducto.Text.Length == 0)
            {
                MessageBox.Show("Escribe el producto primero", "Alerta");
            }
            else {
                int sistema = DateTime.Now.Second;
                string nombreimagen = ""; 
                nombreimagen = "img" + sistema.ToString() + txtproducto.Text + ".png";

                ofd.Filter = "JPEG (*.JPEG) | *.JPG | PNG(*.PNG) | *.PNG";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string[] listaDirectorios = Directory.GetDirectories(rutaraiz);
                    ruta = ofd.FileName;
                    System.IO.File.Copy(ruta, listaDirectorios[0] + nombreimagen, true);
                    imgproducto.Image = Image.FromFile(listaDirectorios[0] + nombreimagen);
                    rutaimagenlocal = listaDirectorios[0] + nombreimagen;
                }
                btnguardar.Enabled = true;
            }
        }

        private void btneliminar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(_id.ToString(), "ID");
            if (_id != -1 && img.Count > 0)
            {
                string rutarelativa = img[0];
                string rutacompleta = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, rutarelativa);

                //Liberar imagenes en el DataGridView
                foreach (DataGridViewRow row in dataProductos.Rows)
                {
                    if (row.Cells[3].Value is Image ImagenCelda)
                    {
                        ImagenCelda.Dispose();
                    }
                }
                //Eliminar archivo si exixte
                if (File.Exists(rutacompleta))
                {
                    try
                    {
                        
                        File.Delete(rutacompleta);
                        MessageBox.Show("Imagen eliminada");
                        Eliminardelarchivo(_id);
                        dataProductos.Rows.RemoveAt(_id);
                        _id = -1;
                        img.Clear();
                        codigoArchivo = "";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al eliminar la imagen: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("La imagen no fue encontrada en: " + rutacompleta);
                }
            }
            else {
                MessageBox.Show("Selecciona un producto valido");
            }
        }

        private void dataProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Eliminardelarchivo(int _id)
        {
            if (_id != -1)
            {
                StreamReader archivo = File.OpenText("productos.csv");
                string renglon = " ";
                int c = 0;
                StreamWriter aux = null;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            if (partes[1].Equals(codigoArchivo))
                            {
                                MessageBox.Show("Imagen borrada", "Ruta local");
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = partes[0] + "," + partes[1] + "," + partes[2] + "," + partes[3];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error");
                    }
                } while (renglon != null);
                archivo.Close();
                File.Delete("productos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "productos.csv");
                    File.Delete("prueba.csv");
                }
            }

        }

        private void btnmodificar_Click(object sender, EventArgs e)
        {
            Modificar modificar = new Modificar(codigoArchivo, nombrep, preciop, imagenp);  
            modificar.ShowDialog();

        }

        private void dataProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;
            if (_id != -1)
            {
                codigoArchivo = dataProductos.Rows[_id].Cells[0].Value.ToString();
                //imagenlocal = dataProductos.Rows[_id].Cells[3].Value.ToString();
                //imagenlocal = dataProductos.Rows[_id].Cells[4].Value.ToString();
                img.Clear();
                img.Add(dataProductos.Rows[_id].Cells[4].Value.ToString());
                nombrep = dataProductos.Rows[_id].Cells[1].Value.ToString();
                preciop = dataProductos.Rows[_id].Cells[2].Value.ToString();
                imagenp = dataProductos.Rows[_id].Cells[4].Value.ToString();
                //MessageBox.Show(imagenlocal, "Aviso");

            }
            else {
                MessageBox.Show("Elige un elemento de la lista");
            }
        }
    }
}
