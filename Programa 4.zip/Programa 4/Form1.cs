﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Revisarimagen();
            crearusuario();  
        }
        private void crearusuario() {
            string usuarios = "usuarios.csv";
            if (!File.Exists(usuarios))
            {
                StreamWriter streamWriter;
                streamWriter = File.AppendText(usuarios);
                streamWriter.Write("admin,123,Administrador");
                streamWriter.Close();

            }
        }
        private void Revisarimagen() {
            OpenFileDialog ofd = new OpenFileDialog();  
            string rutaimagen = "";
            string rutacarpeta = @"\imagenes";
            string rutaraiz = @"imagenes";
            string ruta = "";
            Random random = new Random();
            int nombreArchivo = random.Next(1, 1000);
            if (!Directory.Exists(rutaraiz))
            {
                Directory.CreateDirectory(rutaraiz);
                Directory.CreateDirectory(rutaraiz + rutacarpeta);
                string[] listaDirectorios = Directory.GetDirectories(rutaraiz);
                MessageBox.Show(listaDirectorios[0], "Ruta Carpeta");
                ofd.Filter = "JPEG (*.JPEG) | *.JPG | PNG(*.PNG) | *.PNG";
                if (ofd.ShowDialog() == DialogResult.OK) { 
                    ruta = ofd.FileName;
                    System.IO.File.Copy(ruta, listaDirectorios[0] + "banner" + ".png" , true);
                    Banner.Image = Image.FromFile(listaDirectorios[0] + "banner" + ".png");
                }
            }
            else
            {
                //MessageBox.Show("La carpeta ya existe","Mensaje");
                string[] listaDirectorios = Directory.GetDirectories(rutaraiz);
                Banner.Image = Image.FromFile(listaDirectorios[0] + "banner" + ".png");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string usuarios = "usuarios.csv";
            string dato = "";
            string cu = txtusuario.Text;
            string cp = txtcontra.Text;
            bool encontro = false;  
            if (cu.Length == 0 || cp.Length == 0) {

                MessageBox.Show("Falta ingresar el usuario y la contraseña", "Alerta");
            }
            else {
                if (File.Exists(usuarios))
                {
                    StreamReader sr = new StreamReader(usuarios);
                    do
                    {
                        dato = sr.ReadLine();
                        if (dato != null)
                        {
                            int p = dato.IndexOf(",");
                            int p2 = dato.IndexOf(",", p+1);
                            string u = dato.Substring(0, p);
                            string pa = dato.Substring(p + 1,p2-p-1);
                            if (u.Equals(cu) && pa.Equals(cp))
                            {
                                encontro = true;
                                break;
                            }
                        }
                    } while (dato != null);
                    sr.Close();
                    if (encontro)
                    {
                        this.Hide();
                        Productos productos = new Productos();
                        productos.ShowDialog();
                    }
                    else {
                        MessageBox.Show("El usuario no existe", "Alerta");
                    }
                }
                else {
                    MessageBox.Show("Falta ingresar el usuario y contraseña", "Alerta");
                }
            }
        }

        private void btncerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
