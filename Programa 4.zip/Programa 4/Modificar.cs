﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa_4
{
    public partial class Modificar : Form
    {
        public Modificar(string c, string n, string p, string i)
        {
            InitializeComponent();
            lblcodigo.Text = c;
            txtnombre.Text = n;
            txtprecio.Text = p;
            Imagen.Image = Image.FromFile(i);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Modificar_Load(object sender, EventArgs e)
        {

        }

        private void btmodificar_Click(object sender, EventArgs e)
        {
            Eliminardelarchivo(lblcodigo2.Text, txtnombre.Text, txtprecio.Text);
        }
        private void Eliminardelarchivo(string i, string n, string p)
        {
            
            string codigo = n.Substring(0, 2);
            int hsistema = DateTime.Now.Hour;
            codigo += hsistema.ToString();
            if (!i.Equals(""))
            {
                StreamReader archivo = File.OpenText("productos.csv");
                string renglon = " ";
                int c = 0;
                StreamWriter aux = null;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            if (partes[1].Equals(i))
                            {
                                MessageBox.Show("Imagen borrada", "Ruta local");
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = codigo + "," + n + "," + p + "," + partes[3];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error");
                    }
                } while (renglon != null);
                MessageBox.Show("Datos modificados", "Ventana");
                archivo.Close();
                File.Delete("productos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "productos.csv");
                    File.Delete("prueba.csv");
                }
            }

        }

        private void Imagen_Click(object sender, EventArgs e)
        {

        }
    }
}
