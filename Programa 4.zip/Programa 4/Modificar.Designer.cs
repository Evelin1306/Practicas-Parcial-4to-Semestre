﻿namespace Programa_4
{
    partial class Modificar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncerrar = new System.Windows.Forms.Button();
            this.btmodificar = new System.Windows.Forms.Button();
            this.txtprecio = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.lblprecio = new System.Windows.Forms.Label();
            this.lbnombre = new System.Windows.Forms.Label();
            this.lblcodigo = new System.Windows.Forms.Label();
            this.lblcodigo2 = new System.Windows.Forms.Label();
            this.Imagen = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Imagen)).BeginInit();
            this.SuspendLayout();
            // 
            // btncerrar
            // 
            this.btncerrar.Font = new System.Drawing.Font("Mongolian Baiti", 13.8F, System.Drawing.FontStyle.Bold);
            this.btncerrar.Location = new System.Drawing.Point(331, 413);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(112, 43);
            this.btncerrar.TabIndex = 11;
            this.btncerrar.Text = "Cerrar";
            this.btncerrar.UseVisualStyleBackColor = true;
            // 
            // btmodificar
            // 
            this.btmodificar.Font = new System.Drawing.Font("Mongolian Baiti", 13.8F, System.Drawing.FontStyle.Bold);
            this.btmodificar.Location = new System.Drawing.Point(89, 413);
            this.btmodificar.Name = "btmodificar";
            this.btmodificar.Size = new System.Drawing.Size(124, 43);
            this.btmodificar.TabIndex = 10;
            this.btmodificar.Text = "Modificar";
            this.btmodificar.UseVisualStyleBackColor = true;
            this.btmodificar.Click += new System.EventHandler(this.btmodificar_Click);
            // 
            // txtprecio
            // 
            this.txtprecio.Font = new System.Drawing.Font("Mongolian Baiti", 13.8F, System.Drawing.FontStyle.Bold);
            this.txtprecio.Location = new System.Drawing.Point(282, 353);
            this.txtprecio.Name = "txtprecio";
            this.txtprecio.Size = new System.Drawing.Size(200, 34);
            this.txtprecio.TabIndex = 9;
            // 
            // txtnombre
            // 
            this.txtnombre.Font = new System.Drawing.Font("Mongolian Baiti", 13.8F, System.Drawing.FontStyle.Bold);
            this.txtnombre.Location = new System.Drawing.Point(282, 304);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(200, 34);
            this.txtnombre.TabIndex = 8;
            // 
            // lblprecio
            // 
            this.lblprecio.AutoSize = true;
            this.lblprecio.Font = new System.Drawing.Font("Mongolian Baiti", 13.8F, System.Drawing.FontStyle.Bold);
            this.lblprecio.Location = new System.Drawing.Point(85, 363);
            this.lblprecio.Name = "lblprecio";
            this.lblprecio.Size = new System.Drawing.Size(75, 24);
            this.lblprecio.TabIndex = 7;
            this.lblprecio.Text = "Precio";
            // 
            // lbnombre
            // 
            this.lbnombre.AutoSize = true;
            this.lbnombre.Font = new System.Drawing.Font("Mongolian Baiti", 13.8F, System.Drawing.FontStyle.Bold);
            this.lbnombre.Location = new System.Drawing.Point(85, 314);
            this.lbnombre.Name = "lbnombre";
            this.lbnombre.Size = new System.Drawing.Size(92, 24);
            this.lbnombre.TabIndex = 6;
            this.lbnombre.Text = "Nombre";
            // 
            // lblcodigo
            // 
            this.lblcodigo.AutoSize = true;
            this.lblcodigo.Font = new System.Drawing.Font("Mongolian Baiti", 13.8F, System.Drawing.FontStyle.Bold);
            this.lblcodigo.Location = new System.Drawing.Point(85, 259);
            this.lblcodigo.Name = "lblcodigo";
            this.lblcodigo.Size = new System.Drawing.Size(85, 24);
            this.lblcodigo.TabIndex = 12;
            this.lblcodigo.Text = "Código";
            this.lblcodigo.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblcodigo2
            // 
            this.lblcodigo2.AutoSize = true;
            this.lblcodigo2.Font = new System.Drawing.Font("Mongolian Baiti", 13.8F, System.Drawing.FontStyle.Bold);
            this.lblcodigo2.Location = new System.Drawing.Point(278, 259);
            this.lblcodigo2.Name = "lblcodigo2";
            this.lblcodigo2.Size = new System.Drawing.Size(85, 24);
            this.lblcodigo2.TabIndex = 13;
            this.lblcodigo2.Text = "Código";
            // 
            // Imagen
            // 
            this.Imagen.Location = new System.Drawing.Point(105, 30);
            this.Imagen.Name = "Imagen";
            this.Imagen.Size = new System.Drawing.Size(348, 197);
            this.Imagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Imagen.TabIndex = 14;
            this.Imagen.TabStop = false;
            this.Imagen.Click += new System.EventHandler(this.Imagen_Click);
            // 
            // Modificar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 518);
            this.Controls.Add(this.Imagen);
            this.Controls.Add(this.lblcodigo2);
            this.Controls.Add(this.lblcodigo);
            this.Controls.Add(this.btncerrar);
            this.Controls.Add(this.btmodificar);
            this.Controls.Add(this.txtprecio);
            this.Controls.Add(this.txtnombre);
            this.Controls.Add(this.lblprecio);
            this.Controls.Add(this.lbnombre);
            this.MaximumSize = new System.Drawing.Size(581, 565);
            this.MinimumSize = new System.Drawing.Size(581, 565);
            this.Name = "Modificar";
            this.Text = "Modificar";
            this.Load += new System.EventHandler(this.Modificar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Imagen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncerrar;
        private System.Windows.Forms.Button btmodificar;
        private System.Windows.Forms.TextBox txtprecio;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.Label lblprecio;
        private System.Windows.Forms.Label lbnombre;
        private System.Windows.Forms.Label lblcodigo;
        private System.Windows.Forms.Label lblcodigo2;
        private System.Windows.Forms.PictureBox Imagen;
    }
}